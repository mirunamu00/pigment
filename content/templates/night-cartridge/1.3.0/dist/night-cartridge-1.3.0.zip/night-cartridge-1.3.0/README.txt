Night Cartridge 1.3.0
Start with dist/agent.md. Give your coding agent this folder's path.
