Night Cartridge 0.1.0-rc.5
Start with dist/agent.md. Give your coding agent this folder's path.
