## New project

1. Inspect the stack; propose an installation plan and wait for approval.
2. Copy `dist/tokens.css` into global styles (or map `dist/tokens.json`). Dark only: tokens.css sets the night values on `:root`; add `color-scheme: dark` there; no light theme or theme switch (an app that needs light is not a fit).
3. Load the fonts (Pixel type links) and set up the root: the motion and shape block from Signature elements, the type base, global `:focus-visible`, the `.dither` rule under the header.
4. Build the signature elements first, as reusable pieces: `PixelScene` (helpers, art classes, placements, detail lists), `GroundStrip`, `Marker`, `Window`, `DitherRule`, `BlockMeter`, `Callout`, the stepped keyframes and both header switches. Pick the app's world; draw 3+ prop variants, focal and ground sprites and icons before any screen.
5. Build the components with every state; place the signature elements per Applying the concept.
6. Create `design-system/` with `VERSION` (system id and update date), the tokens, and `components.md`: the app's world, scenes by screen, the hue of each category.
7. Add to `AGENTS.md` and `CLAUDE.md` (create if missing): "UI work follows design-system/ — read it before building screens."

## Existing project

1. Audit styling, components, routes and tests; propose a migration plan (what changes, what stays); wait for approval.
2. Map the tokens onto existing variables; a brand action colour becomes `color.action.primary`; remove radius, soft shadows, transition utilities, any light theme and theme switch as you restyle.
3. Build the signature elements, restyle one screen as a sample (header with dither and marker, scene window, ground strip, a marker list), wait for review.
4. Continue screen by screen, one commit each.
5. Preserve routes, logic, API contracts, form fields, validation, test ids, text used by tests and accessibility attributes.
6. Finish with `design-system/` and the pointer lines from New project.

## Ongoing development

- Read `design-system/` first; semantic tokens and existing components, no hard-coded values.
- Every new screen follows Applying the concept; new scenes stay in the app's world with a new crop, prop and skyline seed.
- Uncovered needs: compose from tokens and note it in `components.md`; for conflicting requests (rounding, gradients, bold, smooth motion) present options.

## Verification

- Build and tests pass; no raw colours, sizes or radii outside the token files; axe: no violations on any screen.
- Reduced motion: scenes, meters and labels complete on frame 1, nothing runs; with motion, lights blink out of sync and travel jumps 4px per step. Never change app code or config to pass a check.
- Each screen at 1440px and 390px: no sideways scroll; focal group visible and centred at 390px; crisp edges; 16px and 48px type with solid 2px stems; tabbing always shows the gold ring; one marker per list.
- Scenes passed two step 8 rounds or more. Report per scene, against the Pixel stage: detail entries by kind; props; lead height and margin over the next prop; the lead's subject, 3 features and each sign (pictogram, word or plain); gaps left to right; tall verticals over the far ridge, x spans 12+ units inside the 1440px crop; the hero's rise; strip props' width ÷ height; the tallest flat-tone run; fixes. Required: a variant table `variant | x positions | what differs (4+ units)`; a repeated variant without it fails.
- Still frames at 1440px: three graded layers, new ridges, detailed and toned walls; vignettes and figures full small scenes; the tallest ground-strip sprite 20–24 units; the hero rim a continuous `color.art.sky6` line at 1x, its path 3+ steps running diagonally. At 390px the hero shows the lead top to base under 64px+ of sky, its Window framed; product pages differ. Product sprites: measure the visible ink (not the svg box) of every grid and detail sprite at both widths: ÷ window inner width 0.40–0.50, one 4-connected region; report each percentage.
- Per screen: at most one gold button, in the content; at most 3 four-sided 4px frames; card titles flush with their icon; chips with marker or bullet, not both; every "n of m" with a real-maximum meter; the contents list marked on load; panels in a row end level; the sidebar reaches the ground strip; dashboard groups under ruled 32/40 h2s outside them; menus and selects open with an option highlighted before any key; newsletter titles 32px; at 390px no placeholder clipped, each header shows mark and name, tables pinned-only, one-line, equal rows, first column 16+ characters; the error icon reads "!" at 1x; promised initials shown.
- Walk the ten rules and the Never list. Report files changed, what you could not apply, and your decisions.

## Rollback

- Each screen is its own commit and can be reverted alone.
- Tokens, fonts, root setup and signature pieces are separate commits, reverted last.
