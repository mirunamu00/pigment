Night Cartridge 1.1.0-rc.1
Start with dist/agent.md. Give your coding agent this folder's path.
