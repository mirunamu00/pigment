Inkleaf 1.1.0
Start with dist/agent.md. Give your coding agent this folder's path.
