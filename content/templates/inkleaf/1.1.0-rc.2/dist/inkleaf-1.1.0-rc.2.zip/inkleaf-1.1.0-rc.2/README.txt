Inkleaf 1.1.0-rc.2
Start with dist/agent.md. Give your coding agent this folder's path.
