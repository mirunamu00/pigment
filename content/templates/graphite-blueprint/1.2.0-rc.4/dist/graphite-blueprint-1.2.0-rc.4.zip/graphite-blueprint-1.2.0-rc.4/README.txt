Graphite Blueprint 1.2.0-rc.4
Start with dist/agent.md. Give your coding agent this folder's path.
